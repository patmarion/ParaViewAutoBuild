""" This module loads all the classes from the VTK Infovis library into
its namespace.  This is an optional module."""

from vtkInfovisPython import *
