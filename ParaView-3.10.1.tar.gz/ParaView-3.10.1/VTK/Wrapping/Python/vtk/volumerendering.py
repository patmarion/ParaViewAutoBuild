""" This module loads all the classes from the VTK VolumeRendering library into
its namespace.  This is an optional module."""

from vtkVolumeRenderingPython import *
