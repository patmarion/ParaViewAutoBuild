""" This module loads all the classes from the VTK Charts library into
its namespace.  This is an optional module."""

from vtkChartsPython import *
