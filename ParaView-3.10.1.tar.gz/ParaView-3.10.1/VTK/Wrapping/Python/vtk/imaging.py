""" This module loads all the classes from the VTK Imaging library into
its namespace.  This is a required module."""

from vtkImagingPython import *
